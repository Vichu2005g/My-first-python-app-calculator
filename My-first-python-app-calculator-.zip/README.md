# My-first-python-app-claclator-
This is a calculator with addition, subtraction, multiplication and division.  This is the first code i've written. 

THis is not too advanced one. its really simple. Just open the python file (only with terminal not by double clicking because i found out that my script is not showing the output or answer of question) and follow the instructions of it!

And this is created to pratice programming and to create a new git hub repo. You can use it to test and you can use it for normal purpose if you want but who does it ;p.

I am also gona add lot of features as I progress in python. My plans are arithmetic solver and lot. 